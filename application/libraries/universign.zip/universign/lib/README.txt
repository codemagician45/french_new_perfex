XMLRPC FOR PHP

project website:
http://phpxmlrpc.sourceforge.net/

WARNING:
PHP module CURL is MANDATORY in order to connect to a SSL xmlrpc server.
