<?php

//URL of universign 
$uni_url= "https://m.freoa@media-partner.fr:Naomi2001@ws.universign.eu/sign/rpc";
//profile used
$uni_profile="default";

?>
